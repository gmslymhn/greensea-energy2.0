const t={width:{type:String,default:"100%"},height:{type:String,default:"280px"}};export{t as b};
