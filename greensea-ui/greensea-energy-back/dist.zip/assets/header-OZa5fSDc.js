const e="/assets/header-MoI1THJb.jpg";export{e as h};
