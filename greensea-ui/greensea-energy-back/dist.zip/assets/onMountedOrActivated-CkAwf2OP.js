import{o as e,y as n,P as a}from"./vue-DXMnW2LW.js";function d(t){let o;e(()=>{t(),n(()=>{o=!0})}),a(()=>{o&&t()})}export{d as o};
