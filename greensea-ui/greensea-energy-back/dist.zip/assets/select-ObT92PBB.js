import{b as o}from"./entry/index-C-m-kmxT-1716556897781.js";const s=t=>o.get({url:"/select/getDemoOptions",params:t});export{s as o};
