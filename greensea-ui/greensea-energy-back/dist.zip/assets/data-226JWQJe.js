const e=(()=>{const o=[];for(let t=0;t<12;t++)o.push({title:"Vben Admin",icon:"logos:vue",color:"#1890ff",active:"100",new:"1,799",download:"bx:bx-download"});return o})();export{e as cardList};
