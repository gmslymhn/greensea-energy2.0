import{b as a}from"./entry/index-C-m-kmxT-1716556897781.js";const o=r=>a.post({url:"/cascader/getAreaRecord",data:r});export{o as a};
