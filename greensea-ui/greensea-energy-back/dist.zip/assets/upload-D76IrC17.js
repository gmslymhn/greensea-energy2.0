import{e as u,b as e}from"./entry/index-C-m-kmxT-1716556897781.js";const{uploadUrl:l=""}=u();function r(o,t){return e.uploadFile({url:l,onUploadProgress:t},o)}export{r as u};
