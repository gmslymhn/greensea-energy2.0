import{b as e}from"./entry/index-C-m-kmxT-1716556897781.js";const p=t=>e.get({url:"/tree/getDemoOptions",params:t});export{p as t};
