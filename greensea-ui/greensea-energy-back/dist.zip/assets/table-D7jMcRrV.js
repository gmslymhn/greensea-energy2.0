import{b as t}from"./entry/index-C-m-kmxT-1716556897781.js";const r=e=>t.get({url:"/table/getDemoList",params:e,headers:{ignoreCancelToken:!0}});export{r as d};
