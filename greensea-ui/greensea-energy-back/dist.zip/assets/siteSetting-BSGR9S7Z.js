const n="https://github.com/anncwb/vue-vben-admin",t="https://doc.vvbin.cn/",s="https://vben.vvbin.cn/";export{t as D,n as G,s as S};
