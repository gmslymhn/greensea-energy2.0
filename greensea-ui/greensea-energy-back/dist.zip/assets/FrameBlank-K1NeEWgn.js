import{d as e,Z as a,_ as n}from"./vue-DXMnW2LW.js";const _=e({name:"FrameBlank",__name:"FrameBlank",setup(r){return(t,o)=>(a(),n("div"))}});export{_ as default};
